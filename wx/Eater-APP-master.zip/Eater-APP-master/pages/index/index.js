var page = {
	data:{
		interval:2000,
		duration:1000,
		imgUrls:['../img/u154.jpg','../img/u160.jpg','../img/u161.png'],
		toptitle:'本周上榜菜谱',
		topcontain:[{src:'../img/1.jpg',title:'油焖大虾',desc:'这是一道我经典菜，味道美极了'},{src:'../img/2.jpg',title:'油焖大虾',desc:'这是一道我经典菜，味道美极了'},{src:'../img/3.jpg',title:'油焖大虾',desc:'这是一道我经典菜，味道美极了'}]
	}

}

Page(page)


